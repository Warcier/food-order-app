<?php

$host = "localhost";
$dbname = "user_database";
$username = "root";
$password = "";

$mysqli = new mysqli($host,$dbname,$username,$password);
if($mysqli->connect_errno){
    die("Connect error" .$mysqli->connect_errno);
}

return $mysqli;