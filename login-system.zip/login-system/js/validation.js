const validation = new JustValidation("#signup");

validation.addField("#name",[
{
    rule:"required"
}

])
.addField("#password",[
    {
        rule:"required"
    },
    {
        rule:"password"
    }
])
.addField("#password_confirmation",[
    {
        validation:(value,fields)=>{
            return value === fields["#password"].elem.value;
        },
        errorMessage:"Password should match"
    }
])
.onSuccess((event)=> {
    document.getElementById("signup").submit();
})